#! /bin/sh
#
#  Authors:
#    Denys Duchier (duchier@ps.uni-sb.de)
# 
#  Contributors:
#    Michael Mehl (mehl@dfki.de)
#    Ralf Scheidhauer (scheidhr@ps.uni-sb.de)
# 
#  Copyright:
#    Organization or Person (Year(s))
# 
#  Last change:
#    $Date: 2004-05-18 15:29:34 +0200 (Tue, 18 May 2004) $ by $Author: glynn $
#    $Revision: 15953 $
# 
#  This file is part of Mozart, an implementation 
#  of Oz 3:
#     http://www.mozart-oz.org
# 
#  See the file "LICENSE" or
#     http://www.mozart-oz.org/LICENSE.html
#  for information on usage and redistribution 
#  of this file, and for a DISCLAIMER OF ALL 
#  WARRANTIES.
#
#

#
# oztool c++ ...        invokes the right c++ compiler with the right options
# oztool cc  ...        same for the c compiler
# oztool ld  ...        creates DLLs
# oztool platform       echoes the oz platform
# oztool version        echoes the oz version 

# determine oztool includes
# Changed for Debian/GNU: Look for includes in /usr/include/mozart -->
if test "${OZTOOL_INCLUDES-NONE}" = NONE; then
  OZTOOL_INCLUDES="-I/usr/include/mozart"
fi

: ${oztool_cxx="i686-linux-gnu-g++  -fno-exceptions  -fpic $OZTOOL_INCLUDES"}
: ${oztool_cc="i686-linux-gnu-gcc  -fpic $OZTOOL_INCLUDES"}
: ${oztool_ld="gcc -shared -Wl,-Bsymbolic-functions"}
: ${oztool_platform="linux-i486"}
: ${oztool_version="1.4.0"}

if test $# -eq 0
then
  cat <<EOF
Usage:
	oztool c++ -c SourceFile
	oztool cc  -c SourceFile
	oztool ld  -o TargetLib FileList
	oztool platform [-o file]
	oztool version
EOF
  exit 2
fi

cmd=$1
shift

case "$cmd" in
  c++) cmd=$oztool_cxx;;
  cc ) cmd=$oztool_cc;;
  ld ) cmd=$oztool_ld;;
  platform )
    case "$1" in
    -o) echo "$oztool_platform" > "$2";;
    * ) echo "$oztool_platform";;
    esac
    exit 0;;
  version ) echo "$oztool_version";
            exit 0;;
  *  )
  echo "oztool: unknown command $cmd" 1>&2
  exit 1
  ;;
esac

exec $cmd "$@"



